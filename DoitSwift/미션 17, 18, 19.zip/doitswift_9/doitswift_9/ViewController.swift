//
//  ViewController.swift
//  doitswift_9
//
//  Created by ASURADA on 2018. 4. 18..
//  Copyright © 2018년 ASURADA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var pageControl: UIPageControl!
    
    var image = ["01.jpg", "02.jpg", "03.jpg", "04.jpg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pageControl.numberOfPages = image.count
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = UIColor.green
        pageControl.currentPageIndicatorTintColor = UIColor.red
        imageView.image = UIImage(named: image[0])
        
        
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(doPinch(_:)))
        self.view.addGestureRecognizer(pinch)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respondToSwipeGesture(_:)))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respondToSwipeGesture(_:)))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRight)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

    @IBAction func pageChanged(_ sender: UIPageControl) {
        
        imageView.image = UIImage(named: image[pageControl.currentPage])
    }
    
    @IBAction func swipeGesture(_ sender: UISwipeGestureRecognizer) {
        
        if sender.direction == .left {
            if pageControl.currentPage > 0 {
                pageControl.currentPage = pageControl.currentPage - 1
            }
        }else if sender.direction == .right {
            if pageControl.currentPage < pageControl.currentPage - 1 {
                pageControl.currentPage = pageControl.currentPage + 1
            }
        }
        imageView.image = UIImage(named: image[pageControl.currentPage])
    }
    
    @objc func respondToSwipeGesture(_ gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.left:
                if (pageControl.currentPage<pageControl.numberOfPages-1) {
                    pageControl.currentPage = pageControl.currentPage + 1
                }
            case UISwipeGestureRecognizerDirection.right:
                if (pageControl.currentPage>0) {
                    pageControl.currentPage = pageControl.currentPage - 1
                }
            default:
                break
            }
            
            imageView.image = UIImage(named: image[pageControl.currentPage])
        }
    }
    
    @objc func doPinch(_ pinch: UIPinchGestureRecognizer) {
        imageView.transform = imageView.transform.scaledBy(x: pinch.scale, y: pinch.scale)
    }
}

